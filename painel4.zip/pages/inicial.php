
 <!-- Main content -->
    <section class="content">

      <div class="row">
	   <?php if(($usuario['tipo']=="revenda") and ($acesso_servidor > 0) ){?>
            
			
		<div class="col-lg-3 col-xs-6">
           <a href="home.php?page=ssh/online">
           <!-- small box -->
           <div class="small-box bg-green">
             <div class="inner">
               <h3 id=" ">Clique aqui para ver</h3>
               <p>Online</p>
             </div>
             <div class="icon">
               <i class="fa fa-rocket"></i>
             </div>
             <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
           </div>
          </a>
         </div>
		    <?php }?>

          <div class="col-lg-3 col-xs-6">
          <a href="home.php?page=contas/listar">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $quantidade_ssh; ?></h3>
              <p>Contas</p>
            </div>
            <div class="icon">
              <i class="fa fa-terminal"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>

        <!-- /.col -->
		    <?php if($usuario['tipo']=="revenda"){?>
        <div class="col-lg-3 col-xs-6">
        <a href="home.php?page=usuario/listar">
        <!-- small box -->
        <div class="small-box bg-blue">
          <div class="inner">
            <h3><?php echo $quantidade_sub; ?></h3>
            <p>Usuários Painel</p>
          </div>
          <div class="icon">
            <i class="fa fa-users"></i>
          </div>
          <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
        </div>
       </a>
      </div>

        <div class="col-lg-3 col-xs-6">
        <a href="home.php?page=servidor/listar">
        <!-- small box -->
        <div class="small-box bg-navy">
          <div class="inner">
            <h3><?php echo $acesso_servidor; ?></h3>
            <p>Servidores</p>
          </div>
          <div class="icon">
            <i class="fa fa-server"></i>
          </div>
          <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
        </div>
       </a>
      </div>
	  
	  <div class="col-lg-3 col-xs-6">
          <a href="http://hostgrid.com.br/upload/vfm-admin/login.php">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3 id="HTTP">BAIXAR ARQUIVOS</h3>
              <p>CLARO-VIVO-OI-TIM-NEXTEL</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>
        <?php }?>