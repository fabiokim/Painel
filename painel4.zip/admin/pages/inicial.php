<?php
if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
{
  header('Location: index.php');exit;
}
?>
  <section class="content-header">
    <h1>
      Dashboard
      <small>Control panel</small>
    </h1>
    <ol class="breadcrumb">
      <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
      <li class="active">Dashboard</li>
    </ol>
  </section>
		
 <!-- Main content -->
    <section class="content-header">

      <div class="row">
       <div class="col-lg-3 col-xs-6">
          <a href="home.php?page=ssh/online">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $total_acesso_ssh_online; ?></h3>
              <p>Online</p>
            </div>
            <div class="icon">
              <i class="fa fa-terminal"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>

        <div class="col-lg-3 col-xs-6">
          <a href="home.php?page=ssh/listar">
          <!-- small box -->
          <div class="small-box bg-purple">
            <div class="inner">
              <h3><?php echo $contas_ssh; ?></h3>
              <p>Contas</p>
            </div>
            <div class="icon">
              <i class="fa fa-terminal"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>



        <div class="col-lg-3 col-xs-6">
          <a href="home.php?page=usuario/revenda">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3><?php echo $all_usuarios_revenda_qtd; ?></h3>
              <p>Revendedores</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>


        <!--<div class="col-lg-3 col-xs-6">
          <a href="home.php?page=usuario/painel">

          <div class="small-box bg-blue">
            <div class="inner">
              <h3><?php echo $all_usuarios_vpn_qtd; ?></h3>
              <p>Usuários Painel</p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>-->

        
        <div class="col-lg-3 col-xs-6">
          <a href="home.php?page=servidor/listar">
          <!-- small box -->
          <div class="small-box bg-navy">
            <div class="inner">
              <h3><?php echo $servidor_qtd ?></h3>
              <p>Servidores</p>
            </div>
            <div class="icon">
              <i class="fa fa-server"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>
		
		
        <div class="col-lg-3 col-xs-6">
          <a href="home.php?page=ssh/contas">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3><?php echo $total_acesso_ssh;?></h3>
              <p>Acessos SSH</p>
            </div>
            <div class="icon">
              <i class="fa fa-rocket"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>
		
		<div class="col-lg-3 col-xs-6">
          <a href="home.php?page=ssh/contas">
          <!-- small box -->
          <div class="small-box bg-orange">
            <div class="inner">
              <h3><?php echo $ssh_susp_qtd;?></h3>
              <p>Contas SSH Susp</p>
            </div>
            <div class="icon">
              <i class="fa fa-globe"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>
		
		<div class="col-lg-3 col-xs-6">
          <a href="home.php?page=usuario/revenda">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3><?php echo $revenda_qtd_susp;?></h3>
              <p>Revendedores Susp</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>
		
		<div class="col-lg-3 col-xs-6">
          <a href="http://hostgrid.com.br/upload/vfm-admin/login.php">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3 id="HTTP">BAIXAR E ENVIAR EHI</h3>
              <p>Configurações</p>
            </div>
            <div class="icon">
              <i class="fa fa-users"></i>
            </div>
            <center>Ver detalhes <i class="fa fa-arrow-circle-right"></i></center>
          </div>
         </a>
        </div>

      </div>
      <!-- /.row -->

    </section>
    <!-- /.content -->
