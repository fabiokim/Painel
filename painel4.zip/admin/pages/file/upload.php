<?php
  /**
  * Script para upload de arquivos
  */
  //ini_set('display_errors',1);
  //ini_set('display_startup_erros',1);

  if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
  {
    header('Location: index.php');exit;
  }

  require_once("../pages/system/seguranca.php");
  protegePagina("admin");

  if (isset($_GET["page"])) {
    $page = $_GET["page"];
  }

  // Flag que indica se há erro ou não
  $erro = null;
  // Quando enviado o formulário
  if (
    isset($_FILES['arquivo']) &&
    isset($_POST['nome']) &&
    isset($_POST["operadora"]) && is_numeric($_POST["operadora"]) &&
    isset($_POST["servidor"]) && is_numeric($_POST["servidor"])
    )
  {
      // Extensões permitidas
      $extensions = array(".ehi", ".ovpn", ".acm", ".epro", ".kpn", ".ktc");

      // Recuperando informações do arquivo
      $file = $_FILES['arquivo']['name'];
      $tmp = $_FILES['arquivo']['tmp_name'];

      //extrai a extensao do arquivo
      $ext = pathinfo($file, PATHINFO_EXTENSION);

      // Caminho onde ficarão os arquivos
      $dir = "../files/".$ext."/";

      // Verifica se a extensão é permitida
      if (!in_array(strtolower(strrchr($file, ".")), $extensions))
      {
  		    $errors = 'Extensão inválida';
  	  }
      // Se não houver erro
      if (!isset($errors)) {
          // Movendo arquivo para servidor
          if (!move_uploaded_file($tmp, $dir.$file))
              $errors = 'Permissão negada!';
      }
      if ($ext==="ehi" || $ext==="ovpn" || $ext==="acm" || $ext==="epro" || $ext==="kpn" || $ext==="ktc") {
        $ok=true;
      }
      else{
        $ok=false;
        $errors = 'Arquivo inválido!';
      }

      if(!isset($errors)){
        $id_servidor = $_POST["servidor"];
        $nome = strtoupper($_POST["nome"]);
        $desc = "arquivo";
        $status = 1;
        $local = "download.php?file=".$file;
        $operadora = $_POST["operadora"];
        if(
          $operadora==="8486" ||
          $operadora==="1010" ||
          $operadora==="2222" ||
          $operadora==="3636" ||
          $operadora==="8080" ||
          $operadora==="8888"
        ){
          $table;

          //Carrega usuarioSSH
            $sql = "INSERT INTO arquivo (id_servidor, nome, operadora, descricao, status, local, tipo)
                  VALUES (
                          '".$id_servidor."',
                          '".$nome."',
                          '".$operadora."',
                          '".$desc."',
                          '".$status."',
                          '".$local."',
                          '".$ext."'
                          )";
          $sql = $conn->prepare($sql);
          $sql->execute();
          if($sql){
            $ok=1;
          }
        }else{
          $errors = "Operadora inválida!";
        }
      }
  }
?>
<section class="content-header">
  <h1>
    Enviar
    <small>Arquivo</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
		<li>Arquivo</li>
    <li class="active">Enviar</li>
  </ol>
</section>
<section class="content">
  <?php
  if (isset($errors)) {
      echo '<div class="alert alert-danger alert-dismissible">';
      echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
      echo '<center>';
      echo "	<h4><i class='icon fa fa-ban'></i>".$errors."</h4>";
      echo '</center>';
      echo "</div>";
  }
  if (isset($ok)) {
      echo '<div class="alert alert-success alert-dismissible">';
      echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
      echo '<center>';
      echo "	<h4><i class='icon fa fa-check'></i>Aquivo enviado!</h4>";
      echo '</center>';
      echo "</div>";
  }
  ?>
  <div class="box box-primary">
    <div class="box-header with-border">
      <center>  <h3 class="box-title">Enviar arquivo</h3></center>
    </div>
    <div class="box-body">
      <form data-toggle="validator" id="upload" action="home.php?page=<?php echo $page; ?>" method="post" enctype="multipart/form-data">
      <div class="form-group">
        <label for="login_ssh">Nome Arquivo</label>
        <input  min="4" max="16" type="text" class="form-control" id="nome" name="nome" placeholder="Digite o nome EHI"
         data-minlength="4" data-maxlength="16" required>
      </div>
      <div class="form-group">
        <label>Operadora </label>
        <select name="operadora" id="operadora" class="select2 select2-selection select2-selection--single" style="width: 100%;"   required>
          <option selected="selected" value="">Escolha uma operadora</option>
          <option value="8486">VIVO</option>
          <option value="1010">TIM</option>
          <option value="2222">TIM BETA</option>
          <option value="3636">CLARO</option>
          <option value="8888">OI</option>
          <option value="8080">NEXTEL</option>
        </select>
      </div>

      <div class="form-group">
        <label>Selecione um servidor </label>
        <select class="select2 select2-selection select2-selection--single" style="width: 100%;"  name="servidor" id="acesso_servidor" required>
        <option selected="selected" value="">Escolha um servidor</option>
          <?php
            $SQLAcesso= "SELECT * FROM servidor  ";
            $SQLAcesso = $conn->prepare($SQLAcesso);
            $SQLAcesso->execute();

            if (($SQLAcesso->rowCount()) > 0) {
              // output data of each row
              while($row_srv = $SQLAcesso->fetch()) {
              $contas_ssh_criadas = 0;

              $SQLServidor = "SELECT * FROM servidor
                              WHERE id_servidor = '".$row_srv['id_servidor']."' ";
              $SQLServidor = $conn->prepare($SQLServidor);
              $SQLServidor->execute();
              $servidor = $SQLServidor->fetch();

              //contas ssh criadas no servidor
              $SQLContasSSH = "SELECT sum(acesso) AS quantidade
                               FROM usuario_ssh
                               WHERE id_servidor = '".$row_srv['id_servidor']."' and id_usuario='".$_SESSION['usuarioID']."' ";
              $SQLContasSSH = $conn->prepare($SQLContasSSH);
              $SQLContasSSH->execute();
              $SQLContasSSH = $SQLContasSSH->fetch();
              $contas_ssh_criadas += $SQLContasSSH['quantidade'];

              ?>
            <option value="<?php echo $row_srv['id_servidor'];?>" > <?php echo $servidor['nome'];?> - <?php echo $servidor['descricao'];?></option>
           <?php }
        }
        ?>
        </select>
      </div>

        <label>Arquivo: </label> <span id="status" style="display: none;"></span> <br>
        <input type="file" name="arquivo" id="arquivo" required>
        <div class="box-footer ">
          <center><button type="submit" class="btn btn-primary">Enviar arquivo</button> </center>
        </div>
    </form>
    </div>
  </div>
</section>
<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="../plugins/select2/select2.full.min.js"></script>
<script src="../dist/js/validator.min.js"></script>

<script>
  $(document).ready(function ($) {
    //Initialize Select2 Elements
    $(".select2").select2();
  });
</script>
