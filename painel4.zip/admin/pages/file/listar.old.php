<?php
#ini_set('display_errors',1);
#ini_set('display_startup_erros',1);
  if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
  {
    header('Location: index.php');exit;
  }else{
    require_once("../pages/system/funcoes.php");
    require_once("../pages/system/seguranca.php");
    protegePagina("admin");

    if (isset($_GET["page"])) {
      $page = $_GET["page"];
    }

    if (isset($_GET["ehi"])) {
      $tipo = "ehi";
      $page = $page."&".$tipo;
      $titulo = "EHI";
    }elseif (isset($_GET["ovpn"])) {
      $tipo = "ovpn";
      $page = $page."&".$tipo;
      $titulo = "OpenVPN";
    }else {
      header('Location: index.php');exit;
    }

    if(isset($_POST["file_id"]) && is_numeric($_POST["file_id"])){
      protegePagina("admin");
      $id_arquivo = $_POST["file_id"];
      $SQLdeletar = "DELETE FROM arquivo
                     WHERE id_arquivo='".$id_arquivo."'
                     AND tipo='".$tipo."' ";
      $SQLdeletar = $conn->prepare($SQLdeletar);
      $SQLdeletar->execute();

      if($SQLdeletar){
          $success = "Arquivo Deletado!";
      }else{
        redirect($page,"denied");
      }

    }
  }
?>
<section class="content-header">
  <?php exibirMensagem(); ?>
  <h1>
    <?php echo $titulo; ?>
    <small>Listar Arquivo</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
		<li>Listar Arquivo</li>
    <li class="active"><?php echo $titulo; ?></li>
  </ol>
</section>
<section class="content">
  <?php

    if (isset($success)) {
        //mensagem de sucesso
        echo '<div class="alert alert-success alert-dismissible">';
        echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
        echo '<center>';
        echo "	<h4><i class='icon fa fa-check'></i>".$success."</h4>";
        echo '</center>';
        echo "</div>";

    }
     $SQLSvrPainel = "SELECT * FROM servidor ORDER BY prioridade DESC";
     $SQLSvrPainel = $conn->prepare($SQLSvrPainel);
     $SQLSvrPainel->execute();

     if(($SQLSvrPainel->rowCount()) > 0){
     	while($rowServer = $SQLSvrPainel->fetch()){
        $cont = 0;
        $SQLFile = "SELECT * from arquivo
                    WHERE id_servidor = '".$rowServer['id_servidor']."'
                    AND tipo='".$tipo."' ";
        $SQLFile = $conn->prepare($SQLFile);
        $SQLFile->execute();
        echo "<h1>".$rowServer['nome']." - ".$rowServer['desc']."</h1>";


        echo "<div class='row'>";
        if(($SQLFile->rowCount()) > 0){
          while($rowEhi = $SQLFile->fetch()){
                  $cont = $cont + 1;
  ?>
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <?php
          if($rowEhi['operadora']=="8486") $color='purple';
          elseif($rowEhi['operadora']=="1010") $color='blue';
          elseif($rowEhi['operadora']=="2222") $color='black';
          elseif($rowEhi['operadora']=="8888") $color='orange';
          elseif($rowEhi['operadora']=="3636") $color='red';
          else $color='gray';
          ?>
          <div class="small-box bg-<?php echo $color; ?>">
            <div class="inner">
              <h3><?php echo $rowEhi['nome']; ?></h3>
              <form role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);echo htmlspecialchars('?page='.$page);?>" method="post">
                <input type="hidden" name="file_id" value="<?php echo $rowEhi['id_arquivo']; ?>">
                <button class="btn btn-danger" type="submit" id="delete"> DELETAR</button>
              </form>
            </div>
            <div class="icon">
              <i class="fa fa-file-o"></i>
            </div>
            <center>Fazer download <i class="fa fa-arrow-circle-down"></i></center>
          </div>
        </div>

    <?php
          }
        }
        echo "</div>";
      }
    }
    ?>

</section>
