<?php
#ini_set('display_errors',1);
#ini_set('display_startup_erros',1);
  if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
  {
    header('Location: index.php');exit;
  }else{
    require_once("../pages/system/funcoes.php");
    require_once("../pages/system/seguranca.php");
    protegePagina("admin");

    if (isset($_GET["page"])) {
      $page = $_GET["page"];
    }

    if (isset($_GET["all"])) {
      $tipo = "all";
      $page = $page."&".$tipo;
      $titulo = "Arquivo";
    }
    elseif (isset($_GET["ehi"])) {
      $tipo = "ehi";
      $page = $page."&".$tipo;
      $titulo = "EHI";
    }
    elseif (isset($_GET["ovpn"])) {
      $tipo = "ovpn";
      $page = $page."&".$tipo;
      $titulo = "OpenVPN";
    }
    elseif (isset($_GET["acm"])) {
      $tipo = "acm";
      $page = $page."&".$tipo;
      $titulo = "ACM";
    }
    elseif (isset($_GET["epro"])) {
      $tipo = "epro";
      $page = $page."&".$tipo;
      $titulo = "eProxy";
    }
    elseif (isset($_GET["kpn"])) {
      $tipo = "kpn";
      $page = $page."&".$tipo;
      $titulo = "KPN";
    }
    elseif (isset($_GET["ktc"])) {
      $tipo = "ktc";
      $page = $page."&".$tipo;
      $titulo = "KTC";
    }
    else {
      header('Location: index.php');exit;
    }

    if(isset($_POST["file_id"]) && is_numeric($_POST["file_id"]) && isset($_POST["op"])){
      $operacao = $_POST["op"];
      $id_arquivo = $_POST["file_id"];

      protegePagina("admin");

      if ($operacao == "delete") {
        $SQLdeletar = "DELETE FROM arquivo
                       WHERE id_arquivo='".$id_arquivo."'
                       AND tipo='".$tipo."' ";
        $SQLdeletar = $conn->prepare($SQLdeletar);
        $SQLdeletar->execute();

        if($SQLdeletar){
            $success = "Arquivo Deletado!";
        }else{
          redirect($page,"denied");
        }
      }
      elseif ($operacao == "alterarStatus") {
        if (isset($_POST["status"]) && $_POST["status"] == 1 || $_POST["status"] == 2) {
          $status = $_POST["status"];

          $SQLStatus = "UPDATE arquivo
                        SET status='".$status."'
                        WHERE id_arquivo='".$id_arquivo."' ";
          $SQLStatus = $conn->prepare($SQLStatus);
          $SQLStatus->execute();

          if($SQLStatus){
              $success = "Status Alterado!";
          }else{
            $error = "Erro ao alterar Status!";
          }
        }else{
          $error = "Arquivo inválido!";
        }

      }


    }
  }
?>
<section class="content-header">
  <?php exibirMensagem(); ?>
  <h1>
    <?php echo $titulo; ?>
    <small>Listar Arquivo</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
		<li>Listar Arquivo</li>
    <li class="active"><?php echo $titulo; ?></li>
  </ol>
</section>
<section class="content">

  <?php
    if (isset($success)) {
        //mensagem de sucesso
        echo '<div class="alert alert-success alert-dismissible">';
        echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
        echo '<center>';
        echo "	<h4><i class='icon fa fa-check'></i>".$success."</h4>";
        echo '</center>';
        echo "</div>";
    }
    elseif (isset($error)) {
            //mensagem de sucesso
            echo '<div class="alert alert-danger alert-dismissible">';
            echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
            echo '<center>';
            echo "	<h4><i class='icon fa fa-check'></i>".$error."</h4>";
            echo '</center>';
            echo "</div>";
        }
  ?>

  <div class="col-xs-12">
    <div class="box box-primary">
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tr>
            <th>Servidor</th>
            <th>Arquivo</th>
            <th>Operadora</th>
            <th>Status</th>
            <th>Ação</th>
          </tr>

      <?php
          $SQLSvrPainel = "SELECT * FROM servidor ORDER BY prioridade DESC";
          $SQLSvrPainel = $conn->prepare($SQLSvrPainel);
          $SQLSvrPainel->execute();

          if(($SQLSvrPainel->rowCount()) > 0){
          	while($rowServer = $SQLSvrPainel->fetch()){
             $cont = 0;

             if ($tipo === "all") {
               $SQLFile = "SELECT * from arquivo
                           WHERE id_servidor = '".$rowServer['id_servidor']."'
                           ";
               $SQLFile = $conn->prepare($SQLFile);
               $SQLFile->execute();
             }else{
               $SQLFile = "SELECT * from arquivo
                           WHERE id_servidor = '".$rowServer['id_servidor']."'
                           AND tipo='".$tipo."' ";
               $SQLFile = $conn->prepare($SQLFile);
               $SQLFile->execute();
             }

             echo "<div class='row'>";
          if(($SQLFile->rowCount()) > 0){
            while($rowEhi = $SQLFile->fetch()){
              $cont = $cont + 1;

              if($rowEhi['operadora']=="8486") {$color='purple';$operadora="VIVO";}
              elseif($rowEhi['operadora']=="1010") {$color='blue';$operadora="TIM";}
              elseif($rowEhi['operadora']=="2222") {$color='black';$operadora="TIM BETA";}
              elseif($rowEhi['operadora']=="8888") {$color='orange';$operadora="OI";}
              elseif($rowEhi['operadora']=="8080") {$color='orange';$operadora="NEXTEL";}
              elseif($rowEhi['operadora']=="3636") {$color='red';$operadora="CLARO";}
              else $color='gray';

              $green = "";
              $yellow = "";
              if ($rowEhi['status'] == 1) {
                $status = '<span class="label label-success"> Funcionando </span>';
                $green = "active";
              }else {
                $status = '<span class="label label-warning"> Em testes </span>';
                $yellow = "active";
              }

          ?>
          <tr>
            <td><?php echo $rowServer["nome"];?></td>
            <td><a href="../<?php echo $rowEhi['local']; ?>"><i class="fa fa-arrow-circle-down"></i> <?php echo $rowEhi['nome']; ?></a></td>
            <td><?php echo $operadora; ?></td>
            <td>
              <?php echo $status;?>
              <div class="box-tools pull-right" data-toggle="tooltip" title="" data-original-title="Alterar Status">

                  <form role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);echo htmlspecialchars('?page='.$page);?>" method="post">
                    <input type="hidden" name="file_id" value="<?php echo $rowEhi['id_arquivo']; ?>">
                    <input type="hidden" name="op" value="alterarStatus">

                    <button name="status" value="1" type="submit" class="btn btn-default btn-sm <?php echo $green; ?>"><i class="fa fa-square text-green"></i>  </button>
                    <button name="status" value="2" type="submit" class="btn btn-default btn-sm <?php echo $yellow; ?>"><i class="fa fa-square text-yellow"></i></button>
                  </form>

              </div>
            </td>
            <td>
              <form role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);echo htmlspecialchars('?page='.$page);?>" method="post">
                <input type="hidden" name="file_id" value="<?php echo $rowEhi['id_arquivo']; ?>">
                <input type="hidden" name="op" value="delete">
                <button class="btn btn-danger btn-xs" type="submit" id="delete"> DELETAR</button>
              </form>
            </td>

          </tr>
      </div>
    </div>
  </div>



    <?php
          }
        }
        echo "</div>";
      }
    }
    ?>

</section>
