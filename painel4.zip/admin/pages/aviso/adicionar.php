
<section class="content-header">
  <h1>
    Adicionar
    <small>Aviso</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
		<li>Aviso</li>
    <li class="active">Adicionar</li>
  </ol>
</section>

<section class="content">
<div class="col-md-6">
    <div class="box">
      <div class="box-header with-border">
        <center>  <h3>Novo Aviso</h3> </center>
      </div>
      <form  data-toggle="validator" role="form" class="form-search form-myform" action="" method="post">
        <div class="box-body">

          <div class="form-group" >
            <label for="titulo">Título</label>
            <input class="form-control" type="text" name="titulo" placeholder="Título" id="titulo">
          </div>

          <div class="form-group" >
            <label for="descricao">Mensagem</label>
            <textarea name="mensagem" rows="3" class="form-control" placeholder="Insira a mensagem desejada" id="mensagem" required data-validation-required-message="Please enter a message."></textarea>
          </div>

        </div>

        <div class="center box-footer">
          <center>
            <div class="btn btn-primary" id="novoAviso">Cadastrar Aviso</div>
          </center>
        </div>

      </form>
    </div>
  </div>
</section>

<!-- Small modal -->
<div id="myModal" class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
	<div class="modal-dialog" role="document">
		<div class="modal-content" >
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="tituloModal"></h4>
			</div>
			<div class="modal-body" id="mensagemModal"></div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary" data-dismiss="modal">Ok</button>
			</div>
		</div>
	</div>
</div>

<script src="../plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="../dist/js/validator.min.js"></script>

<script>
//quando o botão for clicado
$( '#novoAviso' ).click(function() {
  var titulo = $("input[name='titulo']").val();
  var mensagem = $("textarea[name='mensagem']").val();

	// Fazendo requisição AJAX
	$.post('script/cadastrarAviso.php',
	{ op: "novoAviso", titulo:titulo , mensagem:mensagem },
	function (resposta) {
		$('#tituloModal').empty();
		$('#tituloModal').append("Cadastrar Aviso");

		$('#mensagemModal').empty();
		// Exibindo lista
		$('#mensagemModal').append(resposta);
		//exibe mesnagem
		$('#myModal').modal('show');
	});
});

</script>
