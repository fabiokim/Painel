<?php
#ini_set('display_errors',1);
#ini_set('display_startup_erros',1);
  if (basename($_SERVER["REQUEST_URI"]) === basename(__FILE__))
  {
    header('Location: index.php');exit;
  }else{
    require_once("../pages/system/funcoes.php");
    require_once("../pages/system/seguranca.php");
    protegePagina("admin");

    if (isset($_GET["page"])) {
      $page = $_GET["page"];
    }


    if(isset($_POST["aviso_id"]) && is_numeric($_POST["aviso_id"]) && isset($_POST["op"])){
      $operacao = $_POST["op"];
      $id_aviso = $_POST["aviso_id"];

      protegePagina("admin");

      if ($operacao == "delete") {
        $SQLdeletar = "DELETE FROM aviso
                       WHERE id_aviso='".$id_aviso."' ";
        $SQLdeletar = $conn->prepare($SQLdeletar);
        $SQLdeletar->execute();

        if($SQLdeletar){
            $success = "Aviso Deletado!";
        }else{
          redirect($page,"denied");
        }
      }
      elseif ($operacao == "alterarStatus") {
        if (isset($_POST["status"]) && $_POST["status"] == 1 || $_POST["status"] == 2) {
          $status = $_POST["status"];

          $SQLStatus = "UPDATE aviso
                        SET status='".$status."'
                        WHERE id_aviso='".$id_aviso."' ";
          $SQLStatus = $conn->prepare($SQLStatus);
          $SQLStatus->execute();

          if($SQLStatus){
              $success = "Status Alterado!";
          }else{
            $error = "Erro ao alterar Status!";
          }
        }else{
          $error = "Arquivo inválido!";
        }

      }


    }
  }
?>
<section class="content-header">
  <?php exibirMensagem(); ?>
  <h1>
    <?php echo $titulo; ?>
    <small>Listar Aviso</small>
  </h1>
  <ol class="breadcrumb">
    <li><a href="home.php"><i class="fa fa-dashboard"></i> Home</a></li>
		<li>Listar Aviso</li>
    <li class="active"><?php echo $titulo; ?></li>
  </ol>
</section>
<section class="content">

  <?php
    if (isset($success)) {
        //mensagem de sucesso
        echo '<div class="alert alert-success alert-dismissible">';
        echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
        echo '<center>';
        echo "	<h4><i class='icon fa fa-check'></i>".$success."</h4>";
        echo '</center>';
        echo "</div>";
    }
    elseif (isset($error)) {
            //mensagem de sucesso
            echo '<div class="alert alert-danger alert-dismissible">';
            echo '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
            echo '<center>';
            echo "	<h4><i class='icon fa fa-check'></i>".$error."</h4>";
            echo '</center>';
            echo "</div>";
        }
  ?>

  <div class="col-xs-12">
    <div class="box box-primary">
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tr>
            <th>Assunto</th>
            <th>Mensagem</th>
            <th>Ação</th>
          </tr>

      <?php
        $cont = 0;
        $SQLAviso = "SELECT * FROM aviso";
        $SQLAviso = $conn->prepare($SQLAviso);
        $SQLAviso->execute();

        echo "<div class='row'>";
        if(($SQLAviso->rowCount()) > 0){
          while($rowAviso = $SQLAviso->fetch()){
            $cont = $cont + 1;

      ?>
            <tr>
              <td><?php echo $rowAviso["titulo"];?></td>
              <td><?php echo $rowAviso["mensagem"];?></td>
              <td>
                <form role="form" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);echo htmlspecialchars('?page='.$page);?>" method="post">
                  <input type="hidden" name="aviso_id" value="<?php echo $rowAviso['id_aviso']; ?>">
                  <input type="hidden" name="op" value="delete">
                  <button class="btn btn-danger btn-xs" type="submit" id="delete"> DELETAR</button>
                </form>
              </td>

            </tr>
        </div>
      </div>
    </div>

    <?php
          }
        }
        echo "</div>";
    ?>

</section>
